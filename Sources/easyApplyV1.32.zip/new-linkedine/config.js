var config = {}
config.cookieUrl = "https://www.linkedin.com/";
config.defaultUrl = "https://www.linkedin.com/";
config.apiUrl = "http://127.0.0.1:8000/api/";
// config.cvUrl = "https://app.quickapplyjobs.com/public/resume";
// config.cvUrl = "https://sachinkumar.me/quickapply/public";
config.cvUrl = "https://quickapplyforjobs.com/";
//config.cvUrl = "http://127.0.0.1:8000"